#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "BleController.h"

int main(int argc, char *argv[]) {
    QGuiApplication app(argc, argv);
    
    // Registrar controlador C++ para poder usarlo desde QML
    qmlRegisterType<BleController>("VitaBand", 1, 0, "BleController");

    QQmlApplicationEngine engine;
    const QUrl url(u"qrc:/VitaBand/Main.qml"_qs);
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed,
        &app, []() { QCoreApplication::exit(-1); }, Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
